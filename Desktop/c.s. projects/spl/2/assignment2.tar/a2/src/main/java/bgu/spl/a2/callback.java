package bgu.spl.a2;


public interface callback {
	public void call();
}
