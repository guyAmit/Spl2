package bgu.spl.a2.sim.Actions;

import bgu.spl.a2.Action;

public class Close_A_Course<R> extends Action<R> {

	@Override
	protected void start() {
		// TODO Auto-generated method stub
		
	}

}
