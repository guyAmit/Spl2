/**
 * 
 */
package bgu.spl.a2.sim.Actions;

import bgu.spl.a2.Action;

/**
 * @author AdamSh
 *@param <R>
 */
public class Open_A_New_Course<R> extends Action<R> {

	@Override
	protected void start() {
		
	}
}
